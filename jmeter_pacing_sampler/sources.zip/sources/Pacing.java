package org.sibintek.plugin.pacing;


import java.io.Serializable;
import java.util.concurrent.ThreadLocalRandom;

import org.apache.jmeter.engine.event.LoopIterationEvent;
import org.apache.jmeter.engine.event.LoopIterationListener;
import org.apache.jmeter.testelement.AbstractTestElement;
import org.apache.jmeter.timers.Timer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class Pacing extends AbstractTestElement implements Timer, Serializable, LoopIterationListener {

	private static final Logger log = LoggerFactory.getLogger(Pacing.class);

	private static final long serialVersionUID = 1192575506958679602L;

	// store param names
	private static final String MODE_PACING = "Pacing.mode";
	private static final String START_DELAY = "Pacing.start";
	private static final String END_DELAY = "Pacing.end";
	private static final String TYPE_DELAY = "Pacing.type";

	private long previousTime = 0;
	private long delay = 0;

	public Pacing () {
	}

	/**
	 * Retrieve the delay to use during test execution.
	 *
	 * @return the delay.
	 */
	@Override
	public long delay() {
		return delay;
	}

	/**
	 * Provide a description of this timer class.
	 *
	 * @return the description of this timer class.
	 */
	@Override
	public String toString() {
//		return JMeterUtils.getResString("constant_timer_memo"); //$NON-NLS-1$
		return "pacing_memo";
	}

	/**
	 * Gain access to any variables that have been defined.
	 *
	 * @see LoopIterationListener#iterationStart(LoopIterationEvent)
	 */
	@Override
	public void iterationStart(LoopIterationEvent event) {
		delay = getPauseValue();
	}

	// set all settings for every mode
	public void setAllValues(PacingModeEnum pacingEnum, PacingMode pacingMode) {
		if (pacingMode.isEnabled()) {
			setProperty(MODE_PACING, pacingEnum.getValue());
		}
		if (pacingEnum.isEquals(PacingModeEnum.AS_SOON_AS)) {
			return;
		}
		String paramIndex = pacingEnum.getParamIndex();
		setProperty(START_DELAY + paramIndex, pacingMode.getDurationFrom());
		setProperty(END_DELAY + paramIndex, pacingMode.getDurationTo());
		setProperty(TYPE_DELAY + paramIndex, pacingMode.getSelectedType());
	}

	// get all settings from every mode
	public void getAllValues(PacingModeEnum pacingEnum, PacingMode pacingMode) {
		if (getModeEnum().isEquals(pacingEnum)) {
			pacingMode.setModeEnabled();
		}
		if (pacingEnum.isEquals(PacingModeEnum.AS_SOON_AS)) {
			return;
		}
		pacingMode.setDurationFrom(getDurationFrom(pacingEnum));
		pacingMode.setDurationTo(getDurationTo(pacingEnum));
		pacingMode.setSelectedType(getTypeDelay(pacingEnum));
	}


	// getters to read settings from saved in .jmx file
	// ------------------------------------------------------------
	private PacingModeEnum getModeEnum() {
		return PacingModeEnum.getModeFromValue(getPropertyAsInt(MODE_PACING, PacingModeEnum.AS_SOON_AS.getValue()));
	}

	private String getDurationFrom(PacingModeEnum pacingEnum) {
		if (pacingEnum.getParamIndex().isEmpty()) {
			return "0";
		}
		return getPropertyAsString(START_DELAY + pacingEnum.getParamIndex(), "0");
	}

	private String getDurationTo(PacingModeEnum pacingEnum) {
		if (pacingEnum.getParamIndex().isEmpty()) {
			return "1";
		}
		return getPropertyAsString(END_DELAY + pacingEnum.getParamIndex(), "1");
	}

	private String getTypeDelay(PacingModeEnum pacingEnum) {
		if (pacingEnum.getParamIndex().isEmpty()) {
			return TypeInPacingEnum.TYPE_FIXED.getName();
		}
		return getPropertyAsString(TYPE_DELAY + pacingEnum.getParamIndex(), TypeInPacingEnum.TYPE_FIXED.getName());
	}

	private boolean isTypeFixed(PacingModeEnum pacingEnum) {
		String typeName = getTypeDelay(pacingEnum);
		return TypeInPacingEnum.getTypeFromName(typeName).isFixed();
	}
	// ------------------------------------------------------------

	// calculate pacing from stored in .jmx file properties (mode, duration and type)
	private long getPauseValue() {
		PacingModeEnum mode = getModeEnum();
		long pacing;
		switch(mode) {
			case AS_SOON_AS:
				return 0;									// end all, no calculations, no pause
			case AFTER_PREVIOUS_ITERATION_ENDS:
				pacing = calculate(isTypeFixed(mode), getDurationFrom(mode), getDurationTo(mode));
				break;
			case AFTER_PREVIOUS_ITERATION_STARTS:
				long pauseTime = calculate(isTypeFixed(mode), getDurationFrom(mode), getDurationTo(mode));
				long afterPauseTimeStamp = previousTime  + pauseTime;
				long currentTimeStamp = System.currentTimeMillis();
				if (currentTimeStamp > afterPauseTimeStamp) {
					previousTime = currentTimeStamp;
					return 0;								// too late for pause, end all
				}
				previousTime = afterPauseTimeStamp;
				pacing = afterPauseTimeStamp - currentTimeStamp;
				break;
			default:
				return 0;
		}
		return pacing;
	}

	/**
	 * calculate pacing for modes
	 * @param isFixed - is pacing time random (between values) or fixed (one value)
	 * @param startTime - first value if random, the only value in fixed mode
	 * @param endTime - top value in random mode
	 * @return calculated value, randomised if needed
	 */
	private int calculate(boolean isFixed, String startTime, String endTime) {
		int start = getTimeInMillis(startTime);
		int end = getTimeInMillis(endTime);
		end = start < end ? end : start + 1;
//		log.info("start time = " + start + " || end time = " + end);
		return isFixed ? start : ThreadLocalRandom.current().nextInt(start, end);
	}

	/**
	 * get valid time value, parsed to milliseconds
	 * @param timeValueInSec - pacing time parameter. Can have dot or comma
	 * @return pacing time in milliseconds as integer
	 */
	private int getTimeInMillis(String timeValueInSec) {
		char dotValue = '.';
		char comaValue = ',';
    	if (timeValueInSec == null || timeValueInSec.isEmpty()) {
    		return 0;
		}
		if (timeValueInSec.contains(String.valueOf(comaValue))) {
			timeValueInSec = timeValueInSec.replace(comaValue, dotValue);
		}
		if (countCharacterInString(timeValueInSec, dotValue) > 1) {
			log.error("invalid pacing time value: " + timeValueInSec);
			return 0;
		}
		double doubleValue = Double.parseDouble(timeValueInSec);
//		log.info("pacing timeValue = " + timeValueInSec + " || doubleValue = " + doubleValue + " || parsed integer Millis = " + (int) (doubleValue * 1000));
		return (int) (doubleValue * 1000);
	}

	/**
	 * count how many times chosen character could be found in string
	 * @param stringToSearch - string to search in
	 * @param valueToCount - value to search for
	 * @return number, how many times chosen characters were found in string
	 */
	private long countCharacterInString(String stringToSearch, char valueToCount) {
		return stringToSearch.chars().filter(ch -> ch == valueToCount).count();
	}


// public class Pacing extends AbstractSampler implements Interruptible {
//	private transient volatile Thread currentThread;

//	@Override
//	public SampleResult sample(Entry e) {
//		SampleResult res = new SampleResult();
//		res.sampleStart();
////        pause();
//        res.sampleEnd();
//        res.setEndTime(res.getStartTime() + delay);
//        res.setSampleLabel(getName());
//        res.setSuccessful(true);
//        return res;
//	}

//	@Override
//	public boolean interrupt() {
//        Thread thrd = currentThread;
//        if (thrd != null) {
//            thrd.interrupt();
//            return true;
//        }
//        return false;
//	}

	/**
	 * do pause. pacing time depends on mode, random/fixed flags and input values
	 */
//	private void pause() {
//		currentThread = Thread.currentThread();
//		long pacing = getPauseValue();
//		ConstantTimer cTimer = new ConstantTimer();
//		cTimer.setDelay(String.valueOf(pacing));
//		cTimer.delay();
//		try {
//			TimeUnit.MILLISECONDS.sleep(pacing);		// do pause
//		} catch (InterruptedException e) {
//			Thread.currentThread().interrupt();
//		}
//	}

}
