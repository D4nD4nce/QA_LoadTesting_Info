package org.sibintek.plugin.pacing;

import java.awt.BorderLayout;
import java.util.HashMap;
import java.util.Map;
import javax.swing.*;

import org.apache.jmeter.gui.util.HorizontalPanel;
import org.apache.jmeter.gui.util.VerticalPanel;
import org.apache.jmeter.testelement.TestElement;
import org.apache.jmeter.timers.gui.AbstractTimerGui;
import org.apache.jorphan.gui.layout.VerticalLayout;

public class PacingGui extends AbstractTimerGui {

	private static final long serialVersionUID = -169792603917140976L;

    private final Map<PacingModeEnum, PacingMode> allModesMap = new HashMap<>();

    public PacingGui() {
        init();
    }

    @Override
    public String getStaticLabel() {
    	return "Pacing Sampler";
    }

    @Override
    public String getLabelResource() {
    	return "pacing_sampler";
    }

    /**
     * Create the test element underlying this GUI component.
     *
     * @see org.apache.jmeter.gui.JMeterGUIComponent#createTestElement()
     */
    @Override
    public TestElement createTestElement() {
    	Pacing pacing = new Pacing();
        modifyTestElement(pacing);
        pacing.setComment("must be placed under 'flow control action' element");
        return pacing;
    }

    /**
     * Modifies a given TestElement to mirror the data in the gui components.
     * (saves settings to test plan - jmx file)
     * @see org.apache.jmeter.gui.JMeterGUIComponent#modifyTestElement(TestElement)
     */
    @Override
    public void modifyTestElement(TestElement element) {
        super.configureTestElement(element);
        allModesMap.forEach(((Pacing) element)::setAllValues);
    }

    /**
     * Configure this GUI component from the underlying TestElement.
     * (get settings from test plan - jmx file)
     * @see org.apache.jmeter.gui.JMeterGUIComponent#configure(TestElement)
     */
    @Override
    public void configure(TestElement element) {
        super.configure(element);
        allModesMap.forEach(((Pacing) element)::getAllValues);
    }

    /**
     * Initialize this component.
     */
    private void init() {
        // general
    	setLayout(new VerticalLayout(5, VerticalLayout.BOTH, VerticalLayout.TOP));
        setBorder(makeBorder());
        add(makeTitlePanel());
        // general panel for all modes
        VerticalPanel verticalPanel = new VerticalPanel();
        verticalPanel.setBorder(BorderFactory.createTitledBorder(BorderFactory.createEtchedBorder(),"Pacing options")); // $NON-NLS-1$
        // create all modes GUI
        PacingMode.initGUIAll(allModesMap, verticalPanel);
        // panel and default button
        JButton resetSettingsButton = new JButton("Use Defaults");
        HorizontalPanel horizontalPanelReset = new HorizontalPanel();
        horizontalPanelReset.add(resetSettingsButton, BorderLayout.EAST);
        // add default button event
        resetSettingsButton.addActionListener(evt -> PacingMode.setDefaultsCustom(allModesMap, PacingModeEnum.AFTER_PREVIOUS_ITERATION_STARTS));
        // add panels to GUI
        add(horizontalPanelReset);
        add(verticalPanel);
    }

    /**
     * Implements JMeterGUIComponent.clearGui
     */
    @Override
    public void clearGui() {
        super.clearGui();
        PacingMode.clearGUI(allModesMap);
    }
}
