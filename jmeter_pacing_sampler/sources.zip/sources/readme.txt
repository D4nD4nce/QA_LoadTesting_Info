Для компиляции необходимо скачать и корректно открыть под любой IDE (например IDEA) исходники Jmeter не ниже 5ой версии.
В файл build.xml добавить элемент:
  <target name="build-influx-transaction-plugin">
    <jar destfile="./plugin_out/influx_transaction_plugin.jar"
         basedir="${build.dir}/components"
         includes="org/sibintek/old/**">
      <manifest>
        <attribute name="Main-Class" value="org.apache.jmeter.NewDriver"/>
      </manifest>
    </jar>
  </target>

- там же можно отыскать, по какому пути необходимо разместить сами java-файлы.
Для сборки выбрать Ant Target. name - build-pacing-plugin.
В качестве подготовительных шагов перед сборкой необходимо вызывать Ant target 'clean' и Ant target 'compile'.
Готовый jar файл после сборки должен появиться в директории проекта внутри "plugin_out".