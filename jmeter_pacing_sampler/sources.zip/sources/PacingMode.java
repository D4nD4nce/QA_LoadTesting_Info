package org.sibintek.plugin.pacing;

import org.apache.jmeter.gui.util.HorizontalPanel;
import org.apache.jmeter.gui.util.VerticalPanel;

import javax.swing.*;
import java.util.Map;

public class PacingMode {

    private final static String DESCRIPTION_MODE_1 = "Start new iteration as soon as the previous iteration ends";
    private final static String DESCRIPTION_MODE_2 = "Start new iteration after the previous iteration ends, with ";
    private final static String DESCRIPTION_MODE_3 = "Start new iteration at ";

    private final static String TOOLTIP_MODE_1 = "The new iteration begins as soon as possible after the previous iteration ends.";
    private final static String TOOLTIP_MODE_2 = "Starts each new iteration a specified amount of time after the end of the previous iteration. Specify either an exact number of seconds or a range of time.";
    private final static String TOOLTIP_MODE_3 = "You specify the time between iteration—either a fixed number of seconds or a range of seconds from the beginning of the previous iteration. Each scheduled iteration will only begin when the previous iteration is complete.";

    private final static String LABEL_MODE_2 = " delay of ";
    private final static String LABEL_MODE_3 = " intervals, every ";
    private final static String LABEL_TO = " to ";
    private final static String LABEL_SECONDS = " second(s)";

    private final static String DURATION_FIELD_FROM = "60";
    private final static String DURATION_FIELD_TO = "120";

    private PacingModeEnum modeEnum;
    private JRadioButton radioButtonPacingMode;
    private JComboBox<String> comboBoxType;
    private JTextField durationField_From;
    private JTextField durationField_To;
    private JLabel label;

    private PacingMode() {}

    public PacingMode(PacingModeEnum modeEnum) {
        this.modeEnum = modeEnum;
    }

    // initialize gui for all modes inside vertical panel
    public static void initGUIAll(final Map<PacingModeEnum, PacingMode> allModesMap, VerticalPanel verticalPanel) {
        if (allModesMap.isEmpty() || allModesMap.size() < PacingModeEnum.values().length) {
            for (PacingModeEnum oneModeEnum : PacingModeEnum.values()) {
                if (!allModesMap.containsKey(oneModeEnum)) {
                    allModesMap.put(oneModeEnum, new PacingMode(oneModeEnum));
                }
            }
        }
        ButtonGroup buttonGroup = new ButtonGroup();
        for(PacingModeEnum oneModeEnum : PacingModeEnum.values()) {
            verticalPanel.add(allModesMap.get(oneModeEnum).initOneModeGUI(buttonGroup, allModesMap));
        }
//        allModesMap.forEach((modeEnum, mode) -> verticalPanel.add(mode.initOneModeGUI(buttonGroup, allModesMap)));
    }

    // for "clear gui" event
    public static void clearGUI(final Map<PacingModeEnum, PacingMode> allModesMap) {
        setDefaults(allModesMap, PacingModeEnum.AFTER_PREVIOUS_ITERATION_STARTS, false,
                Integer.parseInt(DURATION_FIELD_FROM), Integer.parseInt(DURATION_FIELD_TO));

    }

    // for "use defaults" button
    public static void setDefaultsCustom(final Map<PacingModeEnum, PacingMode> allModesMap, PacingModeEnum defaultMode) {
        setDefaults(allModesMap, defaultMode, true, -1, -1);
    }

    /**
     * general defaults method, changes mode, visibility and values. used only for user input events
     * @param allModesMap - map with all modes in
     * @param defaultMode - mode will be selected
     * @param changeActiveMode - if fields have to be enabled or not
     * @param from - pacing time from
     * @param to - pacing time to (if random)
     */
    public static void setDefaults(final Map<PacingModeEnum, PacingMode> allModesMap, PacingModeEnum defaultMode, boolean changeActiveMode, int from, int to) {
        allModesMap.forEach((modeEnum, mode) -> {
            boolean checkMode = modeEnum.isEquals(defaultMode);
            mode.radioButtonPacingMode.setSelected(checkMode);
            if (mode.comboBoxType != null) {
                mode.comboBoxType.setSelectedIndex(TypeInPacingEnum.TYPE_FIXED.getIndex());
            }
            if (changeActiveMode) {
                mode.setEnabledMode(checkMode);
            }
            if ((from >= 0) && (mode.durationField_From != null)) {
                mode.durationField_From.setText(String.valueOf(from));
            }
            if ((to >= 0) && (mode.durationField_To != null)) {
                mode.durationField_To.setText(String.valueOf(to));
            }
        });
    }

    /**
     * getters for field values
     * ********************************
     */
    public boolean isEnabled() {
        return radioButtonPacingMode.isSelected();
    }

    public String getDurationFrom() {
        if (this.durationField_From == null) {
            return DURATION_FIELD_FROM;
        }
        return this.durationField_From.getText();
    }

    public String getDurationTo() {
        if (this.durationField_To == null) {
            return DURATION_FIELD_TO;
        }
        return this.durationField_To.getText();
    }

    public String getSelectedType() {
        if (this.comboBoxType == null || this.comboBoxType.getSelectedItem() == null) {
            return TypeInPacingEnum.TYPE_FIXED.getName();
        }
        return this.comboBoxType.getSelectedItem().toString();
    }
    // ********************************


    /**
     * setters for field values
     * ********************************
     */
    public void setModeEnabled() {
        radioButtonPacingMode.setSelected(true);
        radioButtonPacingMode.doClick();
    }

    public void setDurationFrom(String value) {
        if (this.durationField_From == null)
            return;
        this.durationField_From.setText(value);
    }

    public void setDurationTo(String value) {
        if(this.durationField_To == null)
            return;
        this.durationField_To.setText(value);
    }

    public void setSelectedType(String value) {
        if (this.comboBoxType == null)
            return;
        for(TypeInPacingEnum enumType : TypeInPacingEnum.values()) {
            if (enumType.getName().equals(value)) {
                this.comboBoxType.setSelectedIndex(enumType.getIndex());
                return;
            }
        }
        this.comboBoxType.setSelectedIndex(TypeInPacingEnum.TYPE_FIXED.getIndex());
    }
    // ********************************


    // init gui for each mode - create all staff on each horizontal panel
    private HorizontalPanel initOneModeGUI(ButtonGroup buttonGroup, final Map<PacingModeEnum, PacingMode> allModesMap) {
        HorizontalPanel horizontalPanel = new HorizontalPanel();
        String firstLabel;
        boolean setFieldsEnabled;
        switch (modeEnum) {
            case AS_SOON_AS:
                radioButtonPacingMode = initRadioButton(DESCRIPTION_MODE_1, TOOLTIP_MODE_1, false);
                buttonGroup.add(radioButtonPacingMode);
                horizontalPanel.add(radioButtonPacingMode);
                return horizontalPanel;
            case AFTER_PREVIOUS_ITERATION_ENDS:
                radioButtonPacingMode = initRadioButton(DESCRIPTION_MODE_2, TOOLTIP_MODE_2, false);
                firstLabel = LABEL_MODE_2;
                setFieldsEnabled = false;
                break;
            case AFTER_PREVIOUS_ITERATION_STARTS:
                radioButtonPacingMode = initRadioButton(DESCRIPTION_MODE_3, TOOLTIP_MODE_3, true);
                firstLabel = LABEL_MODE_3;
                setFieldsEnabled = true;
                break;
            default:
                return horizontalPanel;
        }
        buttonGroup.add(radioButtonPacingMode);
        horizontalPanel.add(radioButtonPacingMode);
        horizontalPanel.add(comboBoxType = initComboBoxType());
        horizontalPanel.add(new JLabel(firstLabel));
        horizontalPanel.add(durationField_From = new JTextField(DURATION_FIELD_FROM));
        horizontalPanel.add(label = new JLabel(LABEL_TO));
        horizontalPanel.add(durationField_To = new JTextField(DURATION_FIELD_TO));
        horizontalPanel.add(new JLabel(LABEL_SECONDS));
        //
        radioButtonPacingMode.addActionListener(event -> {
            if (radioButtonPacingMode.isSelected()) {
                allModesMap.forEach((oneModeEnum, mode) -> mode.setEnabledMode(oneModeEnum.isEquals(modeEnum)));
            }
        });
        setEnabledMode(setFieldsEnabled);
        setVisibleType(false);
        return horizontalPanel;
    }

    // init button for each mode
    private JRadioButton initRadioButton(String buttonText, String toolTipText, boolean setSelected) {
        JRadioButton radioButton = new JRadioButton();
        radioButton.setText(buttonText);
        radioButton.setToolTipText(toolTipText);
        radioButton.setSelected(setSelected);
        radioButton.addChangeListener(evt -> {});
        return radioButton;
    }

    // init ComboBox with types for modes
    private JComboBox<String> initComboBoxType() {
        DefaultComboBoxModel<String> targetModel = new DefaultComboBoxModel<>();
        targetModel.addElement(TypeInPacingEnum.TYPE_FIXED.getName());
        targetModel.addElement(TypeInPacingEnum.TYPE_RANDOM.getName());
        JComboBox<String> comboBox = new JComboBox<>(targetModel);
        comboBox.addActionListener(event -> setVisibleType(TypeInPacingEnum.TYPE_RANDOM.getName().equals(comboBox.getSelectedItem())));
        return comboBox;
    }

    // set input enabled or not for mode horizontal panel
    private void setEnabledMode(boolean enableFlag) {
        boolean isExist = (comboBoxType != null) && (durationField_From != null) && (durationField_To != null);
        if (isExist) {
            comboBoxType.setEnabled(enableFlag);
            durationField_From.setEnabled(enableFlag);
            durationField_To.setEnabled(enableFlag);
        }
    }

    // set last fields in one mode horizontal panel visible or not
    private void setVisibleType(boolean enableFlag) {
        boolean isExist = (label != null) && (durationField_From != null) && (durationField_To != null);
        if (isExist) {
            durationField_From.setVisible(true);
            label.setVisible(enableFlag);
            durationField_To.setVisible(enableFlag);
        }
    }
}
