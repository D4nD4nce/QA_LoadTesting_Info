package org.sibintek.plugin.pacing;

public enum TypeInPacingEnum {

    TYPE_FIXED(0, "Fixed"),
    TYPE_RANDOM(1, "Random");

    private int index;
    private String name;

    TypeInPacingEnum(int index, String name) {
        this.index = index;
        this.name = name;
    }

    public int getIndex() {
        return this.index;
    }

    public String getName() {
        return this.name;
    }

    public boolean isFixed() {
        return this.index == TYPE_FIXED.index;
    }

    public boolean isRandom() {
        return this.index == TYPE_RANDOM.index;
    }

    public static TypeInPacingEnum getTypeFromName(String typeName) {
        for(TypeInPacingEnum type : TypeInPacingEnum.values()) {
            if (type.getName().equals(typeName)) {
                return type;
            }
        }
        return TYPE_FIXED;
    }
}