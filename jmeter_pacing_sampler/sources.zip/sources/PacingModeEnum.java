package org.sibintek.plugin.pacing;

/*
 * --------------------------------------------------------------------------
 * mode enum
 * --------------------------------------------------------------------------
 */

public enum PacingModeEnum {
    AS_SOON_AS(0, ""),
    AFTER_PREVIOUS_ITERATION_ENDS(1, "First"),
    AFTER_PREVIOUS_ITERATION_STARTS(2, "Second");

    private int value;
    private String paramIndex;

    PacingModeEnum(int value, String indexForParams) {
        this.value = value;
        this.paramIndex = indexForParams;
    }

    public int getValue() {
        return value;
    }

    public boolean isEquals(int modeValue) {
        return this.getValue() == modeValue;
    }

    public boolean isEquals(PacingModeEnum mode) {
        return this.getValue() == mode.getValue();
    }

    public String getParamIndex() {
        return this.paramIndex;
    }

    public static PacingModeEnum getModeFromValue(int modeValue) {
        for(PacingModeEnum mode : PacingModeEnum.values()) {
            if (mode.getValue() == modeValue)
                return mode;
        }
        return AS_SOON_AS;
    }
}
